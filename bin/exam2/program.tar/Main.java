import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int timesMatrix[][]; // matriz de tiempos
		Path BestPaths[][]; // matriz auxiliar donde nos apoyaremos en el algortimo (DP)
		Scanner scan = new Scanner(System.in); //leemos los tiempos de entrada estandar
		int l = 0, o = 0;
		boolean finish = false;
		while (!finish &&scan.hasNext()) {
			l = scan.nextInt(); //numero de niveles
			o = scan.nextInt(); //numero de obstaculos en cada nivel
			if (l == 0 && o == 0) {
				finish = true; //fin input
			} else {
				//Inicializamos matrices
				timesMatrix = new int[l][o];
				BestPaths = new Path[l][o];
				//Rellenamos la matriz de tiempos
				for (int i = 0; i < l; i++) {
					for (int j = 0; j < o; j++) {
						timesMatrix[i][j] = scan.nextInt();
						BestPaths[i][j] = new Path();
					}
				}
				// Inicio Algortimo (Rellenado Matriz Auxiliar)
				for (int i = o - 1; i >= 0; i--) { // recorremos columnas (obstaculos) de atras a delante
					for (int j = 0; j < l; j++) { // recorremos filas (niveles)
						if(i == o-1) { // es el ultimo obstaculo, primera iteracion, caso trivial
							BestPaths[j][i].setTime(timesMatrix[j][i]);
							BestPaths[j][i].setPrevLevel(j);
						}else {
							int options[] = new int[l]; //opciones de valores para ir en esta casilla
							for(int x = 0; x < l; x++) {
								options[x]=BestPaths[x][i+1].getTime()+Math.abs(x-j)*5; //cada opcion viene con su correspondiente penalizacion por cambio de nivel
							}
							
							
							//seleccionamos el valor minimo y almacenamos su nivel para luego construir el camino
							int min = Integer.MAX_VALUE;
							int index = 0;
							for (int k = 0; k < l; k++) {
								if(options[k] <= min) {
									min = options[k];
									index = k;
								}
							}
							BestPaths[j][i].setTime(timesMatrix[j][i]+ min); //guardamos el tiempo minimo a nuestra matriz auxiliar
							BestPaths[j][i].setPrevLevel(index); //guardamos tambien de que nivel proviene este tiempo minimo
						}
					}
				}
				
				
				//una vez rellenada la matriz auxiliar en la primera columna tenemos los distintos tiempos, el minimo sera la solucion
				int min = Integer.MAX_VALUE;
				int index = 0;
				for(int i = 0; i < l; i++) {
					if(BestPaths[i][0].getTime() <= min) {
						min = BestPaths[i][0].getTime();
						index = i;
					}
				}
				
				//Printeamos el resultado
				System.out.println(min); //tiempo minimo
				System.out.print("  "+index); // primer nivel
				Path curr = BestPaths[index][0];
				for(int i =1; i<o; i++) { //recorremos la matriz auxiliar sacando los niveles de los que viene este tiempo
					System.out.print("  "+curr.prevLevel);
					curr = BestPaths[curr.prevLevel][i];
				}
				System.out.println("\n");
			}
		}
		scan.close(); //cerramos la entrada
	}

	
	/**
	 * Clase Path:
	 * Objecto que guarda un tiempo y un indice de nivel para saber el ultimo nivel de donde viene ese tiempo
	 * */
	static class Path {
		private int time;
		private int prevLevel;

		Path() {
			time = 0;
			prevLevel = 0;
		}

		public int getTime() {
			return time;
		}

		public void setTime(int t) {
			this.time = t;
		}

		public void setPrevLevel(int l) {
			this.prevLevel = l;
		}
	}

}