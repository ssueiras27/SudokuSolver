import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int timesMatrix[][]; // matriz de tiempos
		Path BestPaths[][]; // matriz para Dynamic Programming
		Scanner scan = new Scanner(System.in);
		int l = 0, o = 0;
		boolean finish = false;
		while (!finish &&scan.hasNext()) {
			l = scan.nextInt();
			o = scan.nextInt();
			if (l == 0 && o == 0) {
				finish = true;
			} else {
				timesMatrix = new int[l][o];
				BestPaths = new Path[l][o];
				for (int i = 0; i < l; i++) {
					for (int j = 0; j < o; j++) {
						timesMatrix[i][j] = scan.nextInt();
						BestPaths[i][j] = new Path();
					}
				}
				// RESOLVEMOS
				for (int i = o - 1; i >= 0; i--) { // columnas
					for (int j = 0; j < l; j++) { // filas
						if(i == o-1) {
							BestPaths[j][i].setTime(timesMatrix[j][i]);
							BestPaths[j][i].setPrevLevel(j);
						}else {
							//OPCIONES
							int options[] = new int[l];
							for(int x = 0; x < l; x++) {
								options[x]=BestPaths[x][i+1].getTime()+Math.abs(x-j)*5;
							} //
							
							//FUNCION MINIMO
							int min = Integer.MAX_VALUE;
							int index = 0;
							for (int k = 0; k < l; k++) {
								if(options[k] <= min) {
									min = options[k];
									index = k;
								}
							}
							BestPaths[j][i].setTime(timesMatrix[j][i]+ min);
							BestPaths[j][i].setPrevLevel(index);
						}
					}
				}
				
				int min = Integer.MAX_VALUE;
				int index = 0;
				for(int i = 0; i < l; i++) {
					if(BestPaths[i][0].getTime() <= min) {
						min = BestPaths[i][0].getTime();
						index = i;
					}
				}
				
				//PRINTEAMOS RESULTADO
				System.out.println(min);
				System.out.print("  "+index);
				Path curr = BestPaths[index][0];
				for(int i =1; i<o; i++) {
					System.out.print("  "+curr.prevLevel);
					curr = BestPaths[curr.prevLevel][i];
				}
				System.out.println("\n");
			}
		}
		scan.close();
	}

	static class Path {
		private int time;
		private int prevLevel;

		Path() {
			time = 0;
			prevLevel = 0;
		}

		public int getTime() {
			return time;
		}

		public void setTime(int t) {
			this.time = this.time + t;
		}

		public void setPrevLevel(int l) {
			this.prevLevel = l;
		}
	}

}