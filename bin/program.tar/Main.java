import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
	private File input;
	private File output;
	private FileWriter fw;
	private Board board;

	public static void main(String[] args) {
		Main sudoku = new Main();
		sudoku.input = new File("input.txt"); // Input file
		sudoku.output = new File("student_output.txt"); // Output file
		sudoku.Start(); // Main routine
	}

	Main() {
	}

	/**
	 * Start(): Main routine of the program, it basically reads sudokus from the
	 * input file one line at a time and loads the value into a Board, then solves
	 * it and finally prints it in the output file.
	 */
	private void Start() {
		try {
			Scanner scan = new Scanner(input);
			fw = new FileWriter(output);
			int lineCounter = 0;
			while (scan.hasNextLine()) {
				if (lineCounter == 0) {
					board = new Board();
				}
				String inputLine = scan.nextLine();
				if (!inputLine.isBlank()) {
					board.loadValuesInLine(inputLine, lineCounter);
					if (lineCounter == 8) {
						Solve();
						PrintBoardToFile(scan.hasNextLine());
					}
					lineCounter = (lineCounter + 1) % 9;
				}
			}
			scan.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * PrintBoardToFile(boolean isLast): The auxiliary method that prints the Board
	 * in the output file, it has a boolean parameter used to prevent from writing
	 * an extra empty line.
	 */
	private void PrintBoardToFile(boolean isLast) {
		try {

			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 9; j++) {
					int value = board.cells[i][j].value;
					char c = Character.forDigit(value, 10);
					fw.write(c);
				}
				fw.write('\n');
			}
			if (isLast)
				fw.write('\n');
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Solve(): The method that start solving the sudoku calling the recursive
	 * function with its initial parameter.
	 */
	private void Solve() {

		SolveREC(InitializeBestFirst());
	}

	/**
	 * ArrayList<Main.Cell> InitializeBestFirst(): This function returns a list of
	 * the cells that are empty sorted by its freedom().
	 */
	private ArrayList<Main.Cell> InitializeBestFirst() {
		ArrayList<Cell> BestFirst = new ArrayList<>();
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				Cell c = board.cells[i][j];
				if (board.cells[i][j].value == 0) {
					BestFirst.add(c);
				}
			}
		}
		BestFirst.sort(new Comparator<Cell>() {
			public int compare(Cell o1, Cell o2) {
				return o1.freedom() - o2.freedom();
			}
		});
		return BestFirst;
	}

	/**
	 * boolean SolveREC(ArrayList<Cell.> auxBestFirst): The recursive method that
	 * solves the sudoku by trying values using the sorted list of cell for
	 * heuristic purposes and optimization, will return true if done;
	 */
	private boolean SolveREC(ArrayList<Cell> auxBestFirst) {
		// PrintLn(auxBestFirst);
		boolean solved = false;
		if (!auxBestFirst.isEmpty()) {
			Cell cell = auxBestFirst.remove(0);
			int freedom = cell.freedom();
			Integer[] possibleValues = cell.possibleValues.toArray(new Integer[freedom]);
			if (freedom >= 1) {
				for (int i = 0; i < freedom && !solved; i++) {
					cell.value = possibleValues[i];
					solved = SolveREC(UpdateBestFirst(auxBestFirst));
					if (!solved)
						cell.value = 0;
				}
			}
			return solved;
		}
		return true;
	}

	/**
	 * ArrayList<Cell.> UpdateBestFirst(ArrayList<Cell.> oldBestFirst): The method
	 * that updates the sorted list by reordering the elements by its freedom again.
	 */
	private ArrayList<Cell> UpdateBestFirst(ArrayList<Cell> oldBestFirst) {
		ArrayList<Cell> BestFirst = new ArrayList<>();
		for (int i = 0; i < oldBestFirst.size(); i++) {
			BestFirst.add(oldBestFirst.get(i));
		}
		BestFirst.sort(new Comparator<Cell>() {
			public int compare(Cell o1, Cell o2) {
				return o1.freedom() - o2.freedom();
			}
		});
		return BestFirst;
	}

	class Board {
		Cell[][] cells;

		Board() {
			cells = new Cell[9][9];
		}

		private void loadValuesInLine(String values, int line) {
			for (int i = 0; i < 9; i++) {
				char c = values.charAt(i);
				if (Character.isDigit(c)) {
					cells[line][i] = new Cell(Character.getNumericValue(c), this, line, i);
				} else {
					cells[line][i] = new Cell(this, line, i);
				}
			}
		}

		public void getPossibles(Cell cell) {
			Set<Integer> possibles = new HashSet<>();
			for (int i = 1; i < 10; i++) {
				possibles.add(i);
			}
			cell.possibleValues = possibles;
			possibles = getPossiblesColumn(cell);
			possibles = getPossiblesLine(cell);
			possibles = getPossiblesCuadrant(cell);
		}

		public Set<Integer> getPossiblesColumn(Cell cell) {
			Set<Integer> possibles = cell.possibleValues;
			int column = cell.column;
			for (int i = 0; i < 9; i++) {
				Cell aux = cells[i][column];
				int auxValue = aux.value;
				if (auxValue != 0 && possibles.contains(auxValue)) {
					possibles.remove(auxValue);
				}
			}
			return possibles;
		}

		public Set<Integer> getPossiblesLine(Cell cell) {
			Set<Integer> possibles = cell.possibleValues;
			int line = cell.line;
			for (int i = 0; i < 9; i++) {
				Cell aux = cells[line][i];
				int auxValue = aux.value;
				if (auxValue != 0 && possibles.contains(auxValue)) {
					possibles.remove(auxValue);
				}
			}
			return possibles;
		}

		public Set<Integer> getPossiblesCuadrant(Cell cell) {
			Set<Integer> possibles = cell.possibleValues;
			int line = cell.line;
			int column = cell.column;
			int mini = 0, maxi = 0, minj = 0, maxj = 0;
			if (line >= 0 && line < 3 && column >= 0 && column < 3) {// 1
				mini = 0;
				maxi = 3;
				minj = 0;
				maxj = 3;
			} else if (line >= 0 && line < 3 && column >= 3 && column < 6) {// 2
				mini = 0;
				maxi = 3;
				minj = 3;
				maxj = 6;
			} else if (line >= 0 && line < 3 && column >= 6 && column < 9) {// 3
				mini = 0;
				maxi = 3;
				minj = 6;
				maxj = 9;
			} else if (line >= 3 && line < 6 && column >= 0 && column < 3) {// 4
				mini = 3;
				maxi = 6;
				minj = 0;
				maxj = 3;
			} else if (line >= 3 && line < 6 && column >= 3 && column < 6) {// 5
				mini = 3;
				maxi = 6;
				minj = 3;
				maxj = 6;
			} else if (line >= 3 && line < 6 && column >= 6 && column < 9) {// 6
				mini = 3;
				maxi = 6;
				minj = 6;
				maxj = 9;
			} else if (line >= 6 && line < 9 && column >= 0 && column < 3) {// 7
				mini = 6;
				maxi = 9;
				minj = 0;
				maxj = 3;
			} else if (line >= 6 && line < 9 && column >= 3 && column < 6) {// 8
				mini = 6;
				maxi = 9;
				minj = 3;
				maxj = 6;
			} else if (line >= 6 && line < 9 && column >= 6 && column < 9) {// 9
				mini = 6;
				maxi = 9;
				minj = 6;
				maxj = 9;
			}
			for (int i = mini; i < maxi; i++) {
				for (int j = minj; j < maxj; j++) {
					Cell aux = cells[i][j];
					int auxValue = aux.value;
					if (auxValue != 0 && possibles.contains(auxValue)) {
						possibles.remove(auxValue);
					}
				}
			}
			return possibles;
		}
	}

	class Cell {
		private Board tablero;
		private int value;
		private Set<Integer> possibleValues;
		private int line;
		private int column;

		Cell(Board t, int l, int c) {
			value = 0;
			tablero = t;
			line = l;
			column = c;
			possibleValues = new HashSet<>();
		}

		Cell(int v, Board t, int l, int c) {
			value = v;
			tablero = t;
			line = l;
			column = c;
		}

		public int freedom() {
			tablero.getPossibles(this);
			return possibleValues.size();
		}

	}
}
