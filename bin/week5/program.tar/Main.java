//package week5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// INPUT
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt();
		List<Point> P = new ArrayList<>(); //List of Points
		List<Point> R = new ArrayList<>(); //List of Points in boundary
		float x, y;
		for (int i = 0; i < n; i++) {
			x = scan.nextFloat();
			y = scan.nextFloat();
			P.add(new Point(x, y));
		}
		scan.close();
		Collections.shuffle(P);
		Circle D = welzlRec(P, R);
		System.out.println(D);
	}

	static Circle welzlRec(List<Point> P, List<Point> R) {
		P = new ArrayList<>(P);
		R = new ArrayList<>(R);
		if (P.isEmpty() || R.size() == 3) {
			return new Circle(R);
		}
		Point p = P.get(0);
		P.remove(0);
		Circle D = welzlRec(P, R);
		if (D.contains(p)) {
			return D;
		}
		R.add(p);
		return welzlRec(P, R);
	}
}

class Point {
	private float x;
	private float y;

	Point(float x, float y) {
		this.x = x;
		this.y = y;
	}

	public float distanceTo(Point o) {
		return (float) Math.sqrt(Math.pow((o.y - this.y),2)+ Math.pow((o.x - this.x),2));
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	@Override
	public String toString() {
		return String.format(Locale.US,"%.2f %.2f",this.x,this.y);
	}
}

class Circle {
	private Point center;
	private float radius;

	Circle(List<Point> R) {
		if (R.isEmpty()) {
			center = new Point(0, 0);
			radius = 0;
		} else if (R.size() == 1) {
			center = R.get(0);
			radius = 0;
		} else if (R.size() == 2) {
			center = new Point((R.get(0).getX() + R.get(1).getX()) / 2, (R.get(0).getY() + R.get(1).getY()) / 2);
			radius = R.get(0).distanceTo(R.get(1))/2;
		} else {
			// Mathematical algorithm from Wikipedia: Circumscribed circle
			float ox = (Math.min(Math.min(R.get(0).getX(), R.get(1).getX()), R.get(2).getX())
					+ Math.max(Math.max(R.get(0).getX(), R.get(1).getX()), R.get(2).getX())) / 2;
			float oy = (Math.min(Math.min(R.get(0).getY(), R.get(1).getY()), R.get(2).getY())
					+ Math.max(Math.max(R.get(0).getY(), R.get(1).getY()), R.get(2).getY())) / 2;
			float ax = R.get(0).getX() - ox, ay = R.get(0).getY() - oy;
			float bx = R.get(1).getX() - ox, by = R.get(1).getY() - oy;
			float cx = R.get(2).getX() - ox, cy = R.get(2).getY() - oy;
			float d = (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by)) * 2;
			float x = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay)
					+ (cx * cx + cy * cy) * (ay - by)) / d;
			float y = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx)
					+ (cx * cx + cy * cy) * (bx - ax)) / d;
			center = new Point(ox + x, oy + y);
			radius = center.distanceTo(R.get(0));
		}
	}

	public boolean contains(Point p) {
		return p.distanceTo(center) <= radius;
	}

	@Override
	public String toString() {
		return this.center + String.format(Locale.US," %.2f",this.radius);
	}
}